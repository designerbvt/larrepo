

// -----( IS Java Code Template v1.2
// -----( CREATED: 2014-07-07 18:25:28 IST
// -----( ON-HOST: VMDBVT02.eur.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class serviecStore

{
	// ---( internal utility methods )---

	final static serviecStore _instance = new serviecStore();

	static serviecStore _newInstance() { return new serviecStore(); }

	static serviecStore _cast(Object o) { return (serviecStore)o; }

	// ---( server methods )---




	public static final void deleteUsers (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(deleteUsers)>> ---
		// @sigtype java 3.5
		IData obj  = IDataFactory.create();
		IDataCursor idc = obj.getCursor();
		IDataUtil.put(idc, "username", "TestUser");
		idc.destroy();
		try {
			Service.doInvoke("wm.server.access", "userDelete", obj);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		obj  = IDataFactory.create();
		idc = obj.getCursor();
		IDataUtil.put(idc, "username", "TestUser_1");
		idc.destroy();
		try {
			Service.doInvoke("wm.server.access", "userDelete", obj);
		} catch (Exception e) {
			e.printStackTrace();
		}
		// --- <<IS-END>> ---

                
	}



	public static final void jsPipeline (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(jsPipeline)>> ---
		// @sigtype java 3.5
		// [i] recref:0:required JMSMessage pub.jms:JMSMessage
		// [o] field:0:required messageOutput
		IDataCursor cursor = pipeline.getCursor();
			
		IData JMSMessage = IDataUtil.getIData(cursor, "JMSMessage");
		IData body = IDataUtil.getIData(JMSMessage.getCursor(), "body");
		IData data = IDataUtil.getIData(body.getCursor(), "data");		
		IDataUtil.put(cursor, "messageOutput", IDataUtil.getString(data.getCursor(), "message"));
		System.out.println("Message_1 "+IDataUtil.getString(data.getCursor(), "message"));
			
		// --- <<IS-END>> ---

                
	}
}

