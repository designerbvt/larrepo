

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.app.b2b.server.Session;
import com.wm.util.JournalLogger;
import com.wm.util.DebugMsg;
// --- <<IS-END-IMPORTS>> ---

public final class cService

{
	// ---( internal utility methods )---

	final static cService _instance = new cService();

	static cService _newInstance() { return new cService(); }

	static cService _cast(Object o) { return (cService)o; }

	// ---( server methods )---



    public static final Values cService (Values in)
    {
        Values out = in;
		// --- <<IS-START(cService)>> ---
		// @specification cService:specification
		// @subtype c
    out = ccService(Service.getSession(), in);
		// --- <<IS-END>> ---
        return out;
                
	}

	// --- <<IS-START-SHARED>> ---
	
	static {
	    try {
	        System.loadLibrary("CService");
	        JournalLogger.log(DebugMsg.LOG_MSG, JournalLogger.FAC_PACKAGE, JournalLogger.INFO, 
				"Loading native library: CService");
	    } catch (UnsatisfiedLinkError e) {
	        JournalLogger.logError(DebugMsg.LOG_MSG, JournalLogger.FAC_PACKAGE, 
				e.getMessage());
	    }
	}
	
	native static Values ccService(Session session, Values in);
		
	// --- <<IS-END-SHARED>> ---
}

