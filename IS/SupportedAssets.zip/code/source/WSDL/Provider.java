package WSDL;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class Provider

{
	// ---( internal utility methods )---

	final static Provider _instance = new Provider();

	static Provider _newInstance() { return new Provider(); }

	static Provider _cast(Object o) { return (Provider)o; }

	// ---( server methods )---




	public static final void HelloWorld_javaService (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(HelloWorld_javaService)>> ---
		// @sigtype java 3.5
		// [i] field:0:required InputString
		// [o] field:0:required OutputString
		//System.out.println("I love my India...");
		// pipeline for reading Input
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	sInputMessage = IDataUtil.getString( pipelineCursor, "InputString" ) + " ... repeating ... " + IDataUtil.getString( pipelineCursor, "InputString" );
		pipelineCursor.destroy();
		
		// pipeline for creating output
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "OutputString", sInputMessage );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}
}

