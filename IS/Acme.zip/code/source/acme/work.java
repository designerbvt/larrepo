package acme;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2014-12-02 15:57:46 UTC
// -----( ON-HOST: sagbase.eur.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.softwareag.util.IDataMap;
// --- <<IS-END-IMPORTS>> ---

public final class work

{
	// ---( internal utility methods )---

	final static work _instance = new work();

	static work _newInstance() { return new work(); }

	static work _cast(Object o) { return (work)o; }

	// ---( server methods )---




	public static final void endsWith (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(endsWith)>> ---
		// @sigtype java 3.5
		// [i] field:0:required string
		// [i] field:0:required suffix
		// [o] field:0:required isSuffix
		// pipeline
		IDataMap idm = new IDataMap(pipeline);
		String	string = idm.getAsString( "string" );
		String	suffix = idm.getAsString( "suffix" );
				
		String isSuffix = string.endsWith(suffix)? "true" : "false";
		
		// pipeline
		idm.put( "isSuffix", isSuffix );
					
		// --- <<IS-END>> ---

                
	}
}

