

// -----( IS Java Code Template v1.2
// -----( CREATED: 2013-02-04 15:19:46 EST
// -----( ON-HOST: MM79874P1.na.mmfg.net

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class Test

{
	// ---( internal utility methods )---

	final static Test _instance = new Test();

	static Test _newInstance() { return new Test(); }

	static Test _cast(Object o) { return (Test)o; }

	// ---( server methods )---




	public static final void testService (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(testService)>> ---
		// @sigtype java 3.5
		// --- <<IS-END>> ---

                
	}
}

