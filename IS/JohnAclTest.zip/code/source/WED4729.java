

// -----( IS Java Code Template v1.2
// -----( CREATED: 2014-12-15 17:21:59 IST
// -----( ON-HOST: VMTROY01.eur.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.Enumeration;
import java.util.Properties;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.wm.app.b2b.server.LogOutputStream;
import com.wm.data.IDataFactory;
import com.wm.app.b2b.server.ServerAPI;
import com.wm.data.IData;
import com.wm.data.IDataCursor;
import com.wm.data.IDataUtil;
// --- <<IS-END-IMPORTS>> ---

public final class WED4729

{
	// ---( internal utility methods )---

	final static WED4729 _instance = new WED4729();

	static WED4729 _newInstance() { return new WED4729(); }

	static WED4729 _cast(Object o) { return (WED4729)o; }

	// ---( server methods )---




	public static final void getKeys (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getKeys)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required environmentKeySetName
		// [o] field:1:required Keys
	// get cursor on pipeline
	IDataCursor idcPipeline = pipeline.getCursor();
	
	// pipeline
	String	environmentKeySetName = IDataUtil.getString( idcPipeline, "property" );
	
	// initialize variables 
	Enumeration keys = null;
	Vector v = new Vector();

	// check to see if properties object is null
	if (properties == null)
	{
		loadProperties( null );
	}

	// get key names from properties object
	keys = properties.propertyNames();

	////////////////////////////////////////////////////////
	// DEBUG
	////////////////////////////////////////////////////////
	LogOutputStream logger = ServerAPI.getLogStream("DANNERS.LOGGERS");
	logger.write("/////////////////////////////////////////////////////");
	logger.write("TEST LOGGING");
	logger.write("/////////////////////////////////////////////////////");
	logger.write("THE NAME IS>>>>>>" + environmentKeySetName);
	// build a vector of the keys
	
	Pattern pattern = Pattern.compile("^[A-Za-z]\\+");
	Matcher matcher = pattern.matcher(environmentKeySetName);
	
	logger.write("BEGIN");
	if(matcher.find()){
		logger.write(matcher.group(1));
	}
	logger.write("END");
	
	while (keys.hasMoreElements())
	{
		String id = (String) keys.nextElement();
		logger.write("The id var is>>>>>>>>>>>>>>>>>>>>>>>" + id);
		if(id.matches("^" + environmentKeySetName + "\\."))
		{//load only these properties based on the first part of the properties value (this denotes the environment set of property keys
			logger.write("MADE IT IN THE IF STATEMENT WE HAD A MATCH!");
			v.addElement(id);
		}
	}

	// put the keys in a string list
    int idCount = v.size();
	if (idCount >0)
	{
		String[] astrKeys = new String[idCount];
		v.copyInto(astrKeys);

		// Put data into pipeline
		idcPipeline.insertAfter("Keys", astrKeys);
	}


	// always destroy your cursor
	idcPipeline.destroy();
	
		// --- <<IS-END>> ---

                
	}



	public static final void getProperties (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getProperties)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:required Keys
		// [o] record:0:required Properties
		// get Cursor on pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		
		// Initialize variables
		String[] strKey   = null;
		String   strValue = null;
		int i;
		IData id = IDataFactory.create();
		IDataCursor idc = id.getCursor();
		
		// Get data from pipeline
		if ( pipelineCursor.first( "Keys" ) )
		{
		 	strKey = (String[]) pipelineCursor.getValue();
		}
		else
		{
			// Input not found
			//util.Log.log("Service: sample.propertyFile:getProperties | required parameter 'Keys' missing", "sample.propertyFile");
			return;
		}
		
		// loop over the keys and get the property values
		for (i = 0; i < strKey.length; i++)
		{
			// Get property from memory
			strValue = getProperty(strKey[i]);
			//util.Log.log("Service: sample.propertyFile:getProperties | " + strKey + ": " + strValue, "sample.propertyFile");
		
			// insert the key and value into the IData object
			idc.insertAfter(strKey[i], strValue);
		}
		
		// Put output into pipeline
		pipelineCursor.last();
		pipelineCursor.insertAfter( "Properties", id );
		
		// Always destroy your cursor
		pipelineCursor.destroy();
		idc.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void loadProperties (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(loadProperties)>> ---
		// @subtype unknown
		// @sigtype java 3.5
    /*
        Retrieves values from configuration file named "yourCustomConfig.cnf" from
        directory [server]/packages/WmSamples/config
    */

	// build the location of the config file
    String configFile = "packages" + File.separator + PACKAGE + File.separator +
                        "config" + File.separator + CONFIG_FILE;

	//util.Log.log("*********************************", "sample.propertyFile");
    //util.Log.log("sample.propertyFile:loadProperties: configFile= " + configFile, "sample.propertyFile");

    try
	{
		// read in the file stream and convert it to a properties object
        FileInputStream configFileInputStream = new FileInputStream( configFile );

		// properties object is already defined in the Shared code
        properties = new Properties();
        properties.load( configFileInputStream );
		propertiesLoaded = true;

        //util.Log.log("*********************************", "sample.propertyFile");
        //util.Log.log("sample.propertyFile:loadProperties", "sample.propertyFile");
        //util.Log.log(properties.toString(), "sample.propertyFile");
        //util.Log.log("*********************************", "sample.propertyFile");
    }
	catch ( FileNotFoundException e )
	{
        // print error to standard out and throw an error
        //util.Log.log( "sample.propertyFile:loadProperties error: Cannot find the config file: " + configFile , "sample.propertyFile");
		Service.throwError("Error finding property file: "+e);
    }
	catch ( IOException e )
	{
        // print error to standard out and throw an error
        //util.Log.log( "b2bStartup.loadProperties error: Cannot read the config file: " + configFile , "sample.propertyFile");
		Service.throwError("Error reading yourCustomConfig.cnf property file: "+e);
    }
	
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
		// initialize static variables
		private static String PACKAGE = "FsUtilities";
		private static String CONFIG_FILE = "vocadoConfig.cnf";
	
	    private static boolean propertiesLoaded = false;
	    private static Properties properties = null;
	
	    /** gets a property from the config file **/
	    public static String getProperty( String key )
	    {
			// check to see if the properties have been loaded
	        if (!propertiesLoaded) {
				try
				{
					//util.Log.log("Shared sample.propertyFile.getProperty() method properties have not been loaded", "sample.propertyFile");
	            	loadProperties( null );
				}
				catch (Exception e)
				{
	//	                try {
	//	                    //util.Log.log("Shared sample.propertyFile.getProperty() method error in call to loadProperties: " + e.toString(), "sample.propertyFile");
	//	                } catch (ServiceException xxx) { /* ignore */ }
				}
	        }
	        if ( properties == null )
	            return( null );
	        else
	            return( properties.getProperty( key ) );
	    }
		
	// --- <<IS-END-SHARED>> ---
}

