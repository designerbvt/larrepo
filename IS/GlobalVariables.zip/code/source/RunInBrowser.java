

// -----( IS Java Code Template v1.2
// -----( CREATED: 2013-06-28 16:36:55 IST
// -----( ON-HOST: VM823SD1.eur.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class RunInBrowser

{
	// ---( internal utility methods )---

	final static RunInBrowser _instance = new RunInBrowser();

	static RunInBrowser _newInstance() { return new RunInBrowser(); }

	static RunInBrowser _cast(Object o) { return (RunInBrowser)o; }

	// ---( server methods )---




	public static final void javsvc (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(javsvc)>> ---
		// @sigtype java 3.5
		IDataUtil.put(pipeline.getCursor(), "B", "Hello B");		
		// --- <<IS-END>> ---

                
	}
}

