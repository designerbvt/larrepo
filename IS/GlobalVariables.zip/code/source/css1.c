/*
 * css1Impl.c:  Generated Service for "flowstep_reorder:css1".
 *
 */

#include "wmJNI.h"
#include "wmUtil.h"

/*
 * Document API for "flowstep_reorder:css1".
 *
 *  The following table lays out the names and types (named DOCUMENT or STRING)
 *  of each document and field used by this service's input and output. The
 *  table is followed by a series of name declarations that must be used to
 *  access (set or get) the field values.
 *
 *  Names are constructed from the DOCUMENT name and the VARIABLE name within
 *  the document.  E.g., 'Order_shipTo' for DOCUMENT 'Order' and VARIABLE
 *  'shipTo'.
 *
 *  Note that fields within arrays and tables are unnamed as they are
 *  accessed by index or indices (indicated by '[]' below).
 *

    Output:  DOCUMENT {
        String s1,
        String[] sl1,
        String[][] st1,
        Output_sd1 sd1,
        Output_sdl1[] sdl1,
        FlowEditor_docs_doc1 sdref1,
        FlowEditor_docs_doc1[] sdreflist1,
    }
    Output_sd1:  DOCUMENT {
    }
    Input_sd1:  DOCUMENT {
    }
    Output_sdl1:  DOCUMENT {
    }
    Input:  DOCUMENT {
        String s1,
        String[] sl1,
        String[][] st1,
        Input_sd1 sd1,
        Input_sdl1[] sdl1,
        FlowEditor_docs_doc1 sdref1,
        FlowEditor_docs_doc1[] sdreflist1,
    }
    FlowEditor_docs_doc1:  DOCUMENT {
    }
    Input_sdl1:  DOCUMENT {
    }
 *
 */

static WmName Output_s1=0;

static WmName Output_sl1=0;

static WmName Output_st1=0;

static WmName Output_sd1=0;

static WmName Output_sdl1=0;

static WmName Output_sdref1=0;

static WmName Output_sdreflist1=0;

static WmName Output_so1=0;

static WmName Output_sol1=0;

static WmName Input_s1=0;

static WmName Input_sl1=0;

static WmName Input_st1=0;

static WmName Input_sd1=0;

static WmName Input_sdl1=0;

static WmName Input_sdref1=0;

static WmName Input_sdreflist1=0;

static WmName Input_so1=0;

static WmName Input_sol1=0;


/**************************** Generated Functions ****************************/

static int initialized=0;

int
init_css1(
    WmContext  *con)
{
    if (initialized)
        return 1;

    if (!WmRecInit(con))
        return 0;

    /*
     * Setup generated document/field names:
     *  Add calls to initialize your custom fields (defined above) here.
     *
     */

    if ((Output_s1 = makeWmName(con, "s1")) == 0) return 0;

    if ((Output_sl1 = makeWmName(con, "sl1")) == 0) return 0;

    if ((Output_st1 = makeWmName(con, "st1")) == 0) return 0;

    if ((Output_sd1 = makeWmName(con, "sd1")) == 0) return 0;

    if ((Output_sdl1 = makeWmName(con, "sdl1")) == 0) return 0;

    if ((Output_sdref1 = makeWmName(con, "sdref1")) == 0) return 0;

    if ((Output_sdreflist1 = makeWmName(con, "sdreflist1")) == 0) return 0;

    if ((Output_so1 = makeWmName(con, "so1")) == 0) return 0;

    if ((Output_sol1 = makeWmName(con, "sol1")) == 0) return 0;

    if ((Input_s1 = makeWmName(con, "s1")) == 0) return 0;

    if ((Input_sl1 = makeWmName(con, "sl1")) == 0) return 0;

    if ((Input_st1 = makeWmName(con, "st1")) == 0) return 0;

    if ((Input_sd1 = makeWmName(con, "sd1")) == 0) return 0;

    if ((Input_sdl1 = makeWmName(con, "sdl1")) == 0) return 0;

    if ((Input_sdref1 = makeWmName(con, "sdref1")) == 0) return 0;

    if ((Input_sdreflist1 = makeWmName(con, "sdreflist1")) == 0) return 0;

    if ((Input_so1 = makeWmName(con, "so1")) == 0) return 0;

    if ((Input_sol1 = makeWmName(con, "sol1")) == 0) return 0;
    initialized = 1;
    return 1;
}

WmRecord *
prepToInvoke_css1(
    JNIEnv    *env,
    jobject   oSession,
    jobject   oIn,
    WmContext *con,
    WmRecord  **session,
    WmRecord  **in,
    WmRecord  **out)
{

    initWmContext(con, env, WM_SVR_CONTEXT);

    if (!init_css1(con))
        return throwWmServiceErrorMsg(con, "Unable to initialize css1");

    *session = makeWmRec(con, oSession, WM_RECORD, 0, 0);
    if (*session == 0) {
        fprintf(stderr, "Unable to construct 'session' handle");
        return throwWmServiceErrorMsg(con, "Unable to construct 'session' handle");
    }
    if (oIn == 0) {
        *in = 0;
        *out = newWmRec(con);
        if (*out == 0) {
            fprintf(stderr, "Unable to construct 'out' handle");
            freeWmRec(session);
            return throwWmServiceErrorMsg(con, "Unable to construct 'out' handle");
        }
    } else {
        *in = makeWmRec(con, oIn, WM_RECORD, 0, 0);
        if (*in == 0) {
            fprintf(stderr, "Unable to construct 'in' handle");
            freeWmRec(out);
            freeWmRec(session);
            return throwWmServiceErrorMsg(con, "Unable to construct 'in' handle");
        }
        *out = *in;
    }

    return NULL;
}

jobject wrapupInvoke_css1(
    WmContext   *con,
    WmRecord    **in,
    WmRecord    **out,
    WmRecord    **session)
{
    jobject oOut = (*out)->ref;

    freeWmRec(session);
    clearWmContext(con);

    return oOut;
}

JNIEXPORT jobject JNICALL
Java_flowstep_1reorder_ccss1 (
    JNIEnv  *env,
    jclass  cServices,
    jobject oSession,
    jobject oIn)
{
    WmRecord *session, *in, *out;
    WmContext con;
    WmRecord *rec;

    WmRecord *Input;    WmRecord *Output;
    /***************************************************/
    /********** Declare your variables here ************/
    /***************************************************/

    /* [default implementation for demo purposes only] */

    char *i_s1=NULL;

    WmRecord *i_sl1=NULL;
    char *isa_sl1=NULL;

    WmRecord *i_st1=NULL;
    char *ist_st1=NULL;
    jsize iz1_st1=0, iz2_st1=0;
    WmRecord *i_sd1=NULL;
    WmRecord *ir_sdl1=NULL, *ia_sdl1=NULL;
    WmRecord *i_sdref1=NULL;
    WmRecord *ir_sdreflist1=NULL, *ia_sdreflist1=NULL;


    WmRecord *o_sl1=NULL;
    WmRecord *o_st1=NULL;
    WmRecord *o_sd1=NULL;
    WmRecord *or_sdl1=NULL, *oa_sdl1=NULL;
    WmRecord *o_sdref1=NULL;
    WmRecord *or_sdreflist1=NULL, *oa_sdreflist1=NULL;

    /***************************************************/
    /********** End of custom declarations *************/
    /***************************************************/

    rec = prepToInvoke_css1(env, oSession, oIn, &con, &session, &in, &out);
    if(rec != NULL )
        return wrapupInvoke_css1(&con, &in, &rec, &session);

    Input = in;
    Output = out;

    /***************************************************/
    /****** Add your custom service logic here *********/
    /***************************************************/

    /* [default implementation for demo purposes only] */
    /* [access inputs] */

    i_s1 = getWmString(Input, Input_s1);

    i_sl1 = getWmStringArray(Input, Input_sl1);
    if (i_sl1 != NULL && getWmArraySize(i_sl1) > 0)
        isa_sl1 = getWmStringByIdx(i_sl1, 0);

    i_st1 = getWmStringTable(Input, Input_st1);
    if (i_st1 != NULL)
        getWmTableSize(i_st1, &iz1_st1, &iz2_st1);
    if (iz1_st1 > 0 && iz2_st1 > 0)
        ist_st1 = getWmStringByIndices(i_st1, 0, 0);
    i_sd1 = getWmRec(Input, Input_sd1);

    ia_sdl1 = getWmRecArray(Input, Input_sdl1);
    if (ia_sdl1 != NULL && getWmArraySize(ia_sdl1) > 0)
        ir_sdl1 = getWmRecByIdx(ia_sdl1, 0);
    i_sdref1 = getWmRec(Input, Input_sdref1);

    ia_sdreflist1 = getWmRecArray(Input, Input_sdreflist1);
    if (ia_sdreflist1 != NULL && getWmArraySize(ia_sdreflist1) > 0)
        ir_sdreflist1 = getWmRecByIdx(ia_sdreflist1, 0);

    /* [process inputs here...] */

    /* [set outputs] */
    setWmString(Output, Output_s1, "s1");

    o_sl1 = newWmStringArray(&con, 1);
    setWmStringByIdx(o_sl1, 0, "sl1");
    setWmStringArray(Output, Output_sl1, o_sl1);

    o_st1 = newWmStringTable(&con, 1, 1);
    setWmStringByIndices(o_st1, 0, 0, "st1");
    setWmStringTable(Output, Output_st1, o_st1);

    o_sd1 = newWmRec(&con);
    setWmRec(Output, Output_sd1, o_sd1);

    or_sdl1 = newWmRec(&con);
    oa_sdl1 = newWmRecArray(&con, 1);
    setWmRecByIdx(oa_sdl1, 0, or_sdl1);
    setWmRecArray(Output, Output_sdl1, oa_sdl1);

    o_sdref1 = newWmRec(&con);
    setWmRec(Output, Output_sdref1, o_sdref1);

    or_sdreflist1 = newWmRec(&con);
    oa_sdreflist1 = newWmRecArray(&con, 1);
    setWmRecByIdx(oa_sdreflist1, 0, or_sdreflist1);
    setWmRecArray(Output, Output_sdreflist1, oa_sdreflist1);

    /* [cleanup] */

    freeWmString(&i_s1);

    freeWmRec(&i_sl1);
    freeWmString(&isa_sl1);

    freeWmRec(&i_st1);
    freeWmString(&ist_st1);
    freeWmRec(&i_sd1);

    freeWmRec(&ir_sdl1);
    freeWmRec(&ia_sdl1);
    freeWmRec(&i_sdref1);

    freeWmRec(&ir_sdreflist1);
    freeWmRec(&ia_sdreflist1);

    freeWmRec(&o_sl1);
    freeWmRec(&o_st1);
    freeWmRec(&o_sd1);

    freeWmRec(&or_sdl1);
    freeWmRec(&oa_sdl1);
    freeWmRec(&o_sdref1);

    freeWmRec(&or_sdreflist1);
    freeWmRec(&oa_sdreflist1);

    /***************************************************/
    /****** End of custom service logic ****************/
    /***************************************************/

    return wrapupInvoke_css1(&con, &in, &out, &session);

}

