package XJ;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2013-06-28 16:32:03 IST
// -----( ON-HOST: VM823SD1.eur.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class YJ

{
	// ---( internal utility methods )---

	final static YJ _instance = new YJ();

	static YJ _newInstance() { return new YJ(); }

	static YJ _cast(Object o) { return (YJ)o; }

	// ---( server methods )---




	public static final void ajsvc (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(ajsvc)>> ---
		// @sigtype java 3.5
		IDataUtil.put(pipeline.getCursor(), "A", "Hello A");
		// --- <<IS-END>> ---

                
	}



	public static final void bjsvc (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(bjsvc)>> ---
		// @sigtype java 3.5
		IDataUtil.put(pipeline.getCursor(), "B", "Hello B");
		ajsvc(pipeline);
		// --- <<IS-END>> ---

                
	}
}

