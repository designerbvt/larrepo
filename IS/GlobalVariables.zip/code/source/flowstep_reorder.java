

// -----( IS Java Code Template v1.2
// -----( CREATED: 2014-05-28 15:52:04 IST
// -----( ON-HOST: VMDBVT02.eur.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.app.b2b.server.Session;
import com.wm.util.JournalLogger;
import com.wm.util.DebugMsg;
// --- <<IS-END-IMPORTS>> ---

public final class flowstep_reorder

{
	// ---( internal utility methods )---

	final static flowstep_reorder _instance = new flowstep_reorder();

	static flowstep_reorder _newInstance() { return new flowstep_reorder(); }

	static flowstep_reorder _cast(Object o) { return (flowstep_reorder)o; }

	// ---( server methods )---



    public static final Values css1 (Values in)
    {
        Values out = in;
		// --- <<IS-START(css1)>> ---
		// @specification FlowEditor.specs:spec1
		// @subtype c
    out = ccss1(Service.getSession(), in);
		// --- <<IS-END>> ---
        return out;
                
	}



	public static final void javass1 (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(javass1)>> ---
		// @sigtype java 3.5
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	
	static {
	    try {
	        System.loadLibrary("flowstep_reorder");
	        JournalLogger.log(DebugMsg.LOG_MSG, JournalLogger.FAC_PACKAGE, JournalLogger.INFO, 
				"Loading native library: flowstep_reorder");
	    } catch (UnsatisfiedLinkError e) {
	        JournalLogger.logError(DebugMsg.LOG_MSG, JournalLogger.FAC_PACKAGE, 
				e.getMessage());
	    }
	}
	
	native static Values ccss1(Session session, Values in);
		
	// --- <<IS-END-SHARED>> ---
}

