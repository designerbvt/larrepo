package net.juniper.services;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.security.SecureRandom;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.time.ZonedDateTime;
import java.util.Base64;
import java.util.Random;
// --- <<IS-END-IMPORTS>> ---

public final class serviceAccounts

{
	// ---( internal utility methods )---

	final static serviceAccounts _instance = new serviceAccounts();

	static serviceAccounts _newInstance() { return new serviceAccounts(); }

	static serviceAccounts _cast(Object o) { return (serviceAccounts)o; }

	// ---( server methods )---




	public static final void decryptHash (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(decryptHash)>> ---
		// @sigtype java 3.5
		// [i] field:0:required hashedString
		// [i] field:0:required pepper
		// [i] field:0:required aesIv
		// [o] field:0:required decryptedString
		try {
			// pipeline
			IDataCursor pipelineCursor = pipeline.getCursor();
			String hashedString = IDataUtil.getString(pipelineCursor, "hashedString");
			String pepper = IDataUtil.getString(pipelineCursor, "pepper");
			String aesIv = IDataUtil.getString(pipelineCursor, "aesIv");
			pipelineCursor.destroy();
		
			SecretKeySpec keyspec = new SecretKeySpec(pepper.getBytes(), "AES");
			IvParameterSpec ivspec = new IvParameterSpec(aesIv.getBytes());
		
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.DECRYPT_MODE, keyspec, ivspec);
			byte[] plainText = cipher.doFinal(Base64.getDecoder().decode(hashedString));
		
			// pipeline
			IDataCursor pipelineCursor_1 = pipeline.getCursor();
			IDataUtil.put(pipelineCursor_1, "decryptedString", new String(plainText));
			pipelineCursor_1.destroy();
		} catch (Exception ex) {
			throw new ServiceException(ex.getMessage());
		}
		// --- <<IS-END>> ---

                
	}



	public static final void generateHash (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(generateHash)>> ---
		// @sigtype java 3.5
		// [i] field:0:required password
		// [i] field:0:required pepper
		// [i] field:0:required aesIv
		// [o] field:0:required hashedString
		try {
			// pipeline
			IDataCursor pipelineCursor = pipeline.getCursor();
			String password = IDataUtil.getString(pipelineCursor, "password");
			String pepper = IDataUtil.getString(pipelineCursor, "pepper");
			String aesIv = IDataUtil.getString(pipelineCursor, "aesIv");
			pipelineCursor.destroy();
		
			SecretKeySpec keyspec = new SecretKeySpec(pepper.getBytes(), "AES");
			IvParameterSpec ivspec = new IvParameterSpec(aesIv.getBytes());
		
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, keyspec, ivspec);
			byte[] cipherText = cipher.doFinal(password.getBytes());
		
			// pipeline
			IDataCursor pipelineCursor_1 = pipeline.getCursor();
			IDataUtil.put(pipelineCursor_1, "hashedString", Base64.getEncoder().encodeToString(cipherText));
			pipelineCursor_1.destroy();
		} catch (Exception ex) {
			throw new ServiceException(ex.getMessage());
		}
			
		// --- <<IS-END>> ---

                
	}
}

