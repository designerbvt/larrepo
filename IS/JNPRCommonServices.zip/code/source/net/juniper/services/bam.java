package net.juniper.services;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.util.coder.IDataXMLCoder;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.regex.Pattern;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import com.amazon.sqs.javamessaging.SQSConnection;
import com.amazon.sqs.javamessaging.SQSConnectionFactory;
import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.InstanceProfileCredentialsProvider;
import com.amazonaws.event.ProgressEvent;
import com.amazonaws.event.ProgressListener;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.AbortMultipartUploadRequest;
import com.amazonaws.services.s3.model.CompleteMultipartUploadRequest;
import com.amazonaws.services.s3.model.InitiateMultipartUploadRequest;
import com.amazonaws.services.s3.model.InitiateMultipartUploadResult;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PartETag;
import com.amazonaws.services.s3.model.UploadPartRequest;
import com.amazonaws.util.SdkHttpUtils;
import com.wm.data.IData;
import com.wm.data.IDataCursor;
import com.wm.data.IDataUtil;
// --- <<IS-END-IMPORTS>> ---

public final class bam

{
	// ---( internal utility methods )---

	final static bam _instance = new bam();

	static bam _newInstance() { return new bam(); }

	static bam _cast(Object o) { return (bam)o; }

	// ---( server methods )---




	public static final void generateBamInstanceId (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(generateBamInstanceId)>> ---
		// @sigtype java 3.5
		// [i] field:0:required instanceId
		// [o] field:0:required bamInstanceId
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	mftInstanceId = IDataUtil.getString( pipelineCursor, "instanceId" );
		pipelineCursor.destroy();
		
		//Convert WM instance Id to BAM allowed id
		StringBuilder instanceBuilder=new StringBuilder();
		char[] ch  = mftInstanceId.toCharArray();
		int maxLength=7;
		int counter=0;
		for (int c = ch.length - 1; c >= 0; c--) 
		{
		int temp = (int)ch[c];
		 
		if(temp<=122 & temp>=97) {
			instanceBuilder.append(temp-96);//for lower case
		}else {
			if(temp<=90 & temp>=65) {
				instanceBuilder.append(temp-64);//for upper case
			}else {
				instanceBuilder.append(temp);
			}
		}
		if(counter < maxLength){
			++counter;
		}else{
			//append random number to make id unique
			//Random rnd = new Random();
			//instanceBuilder.append(100000 + rnd.nextInt(900000));
			break;
		}
		}
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "bamInstanceId", instanceBuilder.toString() );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void publishToBam (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(publishToBam)>> ---
		// @sigtype java 3.5
		SQSConnectionFactory scf = null;
		SQSConnection sc = null;
		QueueSession qs = null;
		Queue queue = null;
		TextMessage message = null;
		MessageProducer producer =null;
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			IData input = IDataFactory.create();
			IDataCursor inputCursor = input.getCursor();
			
			IData	document = IDataFactory.create();
			IDataCursor dc=document.getCursor();
			String queueName=IDataUtil.getString( pipelineCursor,"queueName" );
			String region=IDataUtil.getString( pipelineCursor,"region" );
			String key=IDataUtil.getString( pipelineCursor,"key" );
			String secret=IDataUtil.getString( pipelineCursor,"secret" );
			IDataUtil.put( dc, "prefix0:actionData", IDataUtil.getIData( pipelineCursor,"prefix0:actionData" ) );
			dc.destroy();
			IDataUtil.put( inputCursor, "document", document );
			
			IData	nsDecls = IDataFactory.create();
			IDataCursor ns=nsDecls.getCursor();
			IDataUtil.put( ns, "prefix0", "http://xmlns.oracle.com/bpel/sensor" );
			IDataUtil.put( ns, "prefix1", "http://www.juniper.net/jnprMonitor/v1" );
			IDataUtil.put( ns, "ns", "http://www.juniper.net/jnprMonitor/v1" );
			ns.destroy();
			IDataUtil.put( inputCursor, "nsDecls", nsDecls );
			inputCursor.destroy();
		
			// output
			IData 	output = IDataFactory.create();
		
			try{
				output = Service.doInvoke( "pub.xml", "documentToXMLString", input );
				IDataCursor outputCursor = output.getCursor();
				String	xmldata = IDataUtil.getString( outputCursor, "xmldata" );
				outputCursor.destroy();
			
			 if(xmldata != null){
				 //bug in SQSConnectionFactory
				System.setProperty("sqsRegion", region != null ? region : "US_WEST_2");
			    scf = new SQSConnectionFactory();
				if(key != null && secret != null){
					sc = scf.createConnection(key,secret);
				}else{
					 sc = scf.createConnection();
				}
			    qs =  sc.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
			    queue = qs.createQueue(queueName);
			    producer = qs.createProducer(queue);
			    message = qs.createTextMessage(xmldata);
		
				producer.send(message);
				message = null;
			 }
				
			}catch(Exception e){
				e.printStackTrace();
				com.wm.util.JournalLogger.log(3,90,3,"Error while publishing to BAM SQS. " + e.getLocalizedMessage());
				
			}finally{
				
				pipelineCursor.destroy();
			
		    if(producer !=null ){
		        try {
		            producer.close();
		        } catch (JMSException e) {
		        	com.wm.util.JournalLogger.log(3,90,3,"LOG " + "Error while closing the SQS Jms producer. error is " + e.getLocalizedMessage());
				}
		    }
		    if (sc != null) {
		        try {
		            sc.close();
		        } catch (JMSException e) {
		        	com.wm.util.JournalLogger.log(3,90,3,"LOG " + "Error while closing the SQS Jms connection. error is " + e.getLocalizedMessage());
		        }
		    }
		}
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---

	
	// --- <<IS-END-SHARED>> ---
}

