This recipe contains 4 use case :

1. WmrTransformUsingForEach.services:manyToOneMapping : This service demonstrate many to one mapping use-case, you can map multiple Input Arrays to one Output Array and based on the ForEach setting, the elements will be copied to Output array.
In this service I am setting Copy mode action = MERGE, so all the elements from 3 arrays are getting merged into one Output Array.

2. WmrTransformUsingForEach.services:nestedForEach : This service demonstrate nested for each mapping use-case. In this service the Input array User has a nested array Address and which is mapped to nested array Address of Output Array Employee. 

3. WmrTransformUsingForEach.services:oneToManyMapping : This service demonstrate one to many mapping use-case, you can map one Input Array to multiple Output Arrays and based on the ForEach setting, the elements will be copied to Output arrays.
In this service I am setting Filter criteria for each mapping, based on the filter criteria the elements will be copied to output arrays.

4. WmrTransformUsingForEach.services:transformInputArray : This service demonstrate simple use-case of transforming the input array to output array.