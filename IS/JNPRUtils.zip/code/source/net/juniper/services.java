package net.juniper;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.app.b2b.server.ServerAPI;
import com.wm.util.coder.IDataXMLCoder;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
// --- <<IS-END-IMPORTS>> ---

public final class services

{
	// ---( internal utility methods )---

	final static services _instance = new services();

	static services _newInstance() { return new services(); }

	static services _cast(Object o) { return (services)o; }

	// ---( server methods )---




	public static final void StringToInteger (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(StringToInteger)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required input
		// [o] object:0:required output
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	input = IDataUtil.getString( pipelineCursor, "input" );
		
		pipelineCursor.destroy();
		try{
		
			BigDecimal inputDecimal= new BigDecimal(input);
			Integer output=new Integer(inputDecimal.intValue());
			IDataCursor pipelineCursor_1 = pipeline.getCursor();
			IDataUtil.put( pipelineCursor_1, "output", output );
			pipelineCursor_1.destroy();
			
		}catch(Exception ex){
		throw new ServiceException(ex.getMessage());
		}
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void contains (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(contains)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required inString
		// [i] field:0:required searchString
		// [o] field:0:required flag
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	inString = IDataUtil.getString( pipelineCursor, "inString" );
		String	searchString = IDataUtil.getString( pipelineCursor, "searchString" );
		pipelineCursor.destroy();
		
		String flag = "false";
		int index = inString.indexOf(searchString);
		
		if ( index >= 0 )
		   flag = "true";
		else
		   flag = "false";
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "flag", flag );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void convertPipelineToString (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(convertPipelineToString)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		String op=null;
		try{
			ByteArrayOutputStream os = new ByteArrayOutputStream();
			IDataXMLCoder xc = new IDataXMLCoder();
			xc.encode(os, pipeline);
			op=os.toString("UTF8");
		}
		catch(Exception ex){
			throw new ServiceException(ex.getMessage());
		}
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		IDataUtil.put( pipelineCursor, "output", op );
		pipelineCursor.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void convertStringToDate (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(convertStringToDate)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required inDate
		// [i] field:0:required inDateFormat
		// [o] object:0:required outDate
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	inDate = IDataUtil.getString( pipelineCursor, "inDate" );
		String	reqFormat = IDataUtil.getString( pipelineCursor, "inDateFormat" );
		pipelineCursor.destroy();
		
		if(reqFormat == null || reqFormat.trim().equals(""))
			reqFormat = "MM/dd/yyyy HH:mm:ss";
		
		if( inDate == null || inDate.trim().equals("") ) {
			//outDate = null;
		} else {
		    Date outDate = null;
		    try
		      {
			  SimpleDateFormat sdf = new SimpleDateFormat(reqFormat);
			  outDate = sdf.parse(inDate);
		      }
		      catch(IllegalArgumentException ie)
		      {
			  throw new ServiceException(ie.toString());
		      }
		      catch(ParseException pe)
		      {
			 throw new ServiceException(pe.toString());
		      }
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		//Object outDate = new Object();
		IDataUtil.put( pipelineCursor_1, "outDate", outDate );
		pipelineCursor_1.destroy();
		}
			
		// --- <<IS-END>> ---

                
	}



	public static final void convertStringToPipeline (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(convertStringToPipeline)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	inputString = IDataUtil.getString( pipelineCursor, "inputString" );
		pipelineCursor.destroy();
		//IData pipeline=null;
		
		try{
		ByteArrayInputStream is=new ByteArrayInputStream(inputString.getBytes());
		IDataXMLCoder xc = new IDataXMLCoder();
		IDataUtil.merge(xc.decode(is), pipeline);
		}
		catch(Exception ex){
			throw new ServiceException(ex.getMessage());
		}
		// --- <<IS-END>> ---

                
	}



	public static final void createRandomNumber (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(createRandomNumber)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] object:0:required randomNumber
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		long randomNumber = 1+(long)(Math.random()*1000000000);
		IDataUtil.put( pipelineCursor, "randomNumber", randomNumber+"");
		pipelineCursor.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void decodeDate (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(decodeDate)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required inDate
		// [i] field:0:required format
		// [o] field:0:required outStrDate
			// pipeline
			IDataCursor pipelineCursor = pipeline.getCursor();
			Object	inDate = IDataUtil.get( pipelineCursor, "inDate" );
			String sFormat = (String)IDataUtil.get( pipelineCursor, "format" );
			pipelineCursor.destroy();
		
			if(sFormat == null || sFormat.equals(""))
				sFormat = "MM/dd/yyyy HH:mm:ss";
				SimpleDateFormat sdf = null;
				String outStrDate = "";
				try {
					sdf = new SimpleDateFormat(sFormat);
					outStrDate = sdf.format(inDate);
				} catch (IllegalArgumentException ie) {
					sFormat = "MM/dd/yyyy HH:mm:ss";
					sdf = new SimpleDateFormat(sFormat);
					outStrDate = sdf.format(inDate);
				}
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "outStrDate", outStrDate );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void encodeDate (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(encodeDate)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required inDate
		// [o] object:0:required outDate
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	inDate = IDataUtil.getString( pipelineCursor, "inDate" );
		pipelineCursor.destroy();
		Date outDate = null;
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		if (inDate == null || inDate.trim() == "" || inDate.length() <= 1) {}
		 else {
		// pipeline
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		StringTokenizer st = new StringTokenizer(inDate, "-");
		
		String date = st.nextToken();
		String month = (st.nextToken()).toUpperCase();
		int iMonth = 0;
		
		try
		{
			iMonth = Integer.parseInt(month);
			month = String.valueOf(iMonth-1);
		}
		catch(NumberFormatException ne)
		{
		}
		
		String year = st.nextToken();
		
		if(month.startsWith("JAN"))
			month = "00";
		else if(month.startsWith("FEB"))
			month = "01";
		else if(month.startsWith("MAR"))
			month = "02";
		else if(month.startsWith("APR"))
			month = "03";
		else if(month.startsWith("MAY"))
			month = "04";
		else if(month.startsWith("JUN"))
			month = "05";
		else if(month.startsWith("JUL"))
			month = "06";
		else if(month.startsWith("AUG"))
			month = "07";
		else if(month.startsWith("SEP"))
			month = "08";
		else if(month.startsWith("OCT"))
			month = "09";
		else if(month.startsWith("NOV"))
			month = "10";
		else if(month.startsWith("DEC"))
			month = "11";
		//
		
		Calendar cal = Calendar.getInstance();
		cal.clear();
		cal.clear(Calendar.HOUR_OF_DAY);
		cal.set(Integer.parseInt(year), Integer.parseInt(month), Integer.parseInt(date));//, 0, 0, 0);
		
		outDate = cal.getTime();
		}
		
		IDataUtil.put( pipelineCursor_1, "outDate", outDate );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void endsWith (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(endsWith)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required inString
		// [i] field:0:required searchString
		// [o] field:0:required flag
		
		String	inString = null;
		String	searchString = null;
		
		IDataCursor pipelineCursor = pipeline.getCursor();
		if(pipelineCursor.first("inString"))
			inString = IDataUtil.getString( pipelineCursor, "inString" );
		else
			throw new ServiceException("In String is null");
		
		if(pipelineCursor.first("searchString"))
			searchString = IDataUtil.getString( pipelineCursor, "searchString" );
		else
			throw new ServiceException("Search String is null");
		
		pipelineCursor.destroy();
		
		boolean bFlag = inString.endsWith(searchString);
		String flag = String.valueOf(bFlag);
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "flag", flag );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void gc (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(gc)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		System.gc();
		// --- <<IS-END>> ---

                
	}



	public static final void getCallingService (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getCallingService)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] field:0:required callingService
		String caller;
		
		try
		{
			caller = Service.getCallingService().toString();
		} catch (Exception e)
		{
			caller = "null";
		}
		
		IDataCursor pc = pipeline.getCursor();
		pc.first();
		pc.insertAfter("callingService",caller);
		pc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getEncodingType (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getEncodingType)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required stream
		// [o] field:0:required encodingType
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		InputStream	stream = (InputStream)IDataUtil.get( pipelineCursor, "stream" );
		pipelineCursor.destroy();
		
				BufferedReader bufferedReader = null;
				String encoding = System.getProperty("file.encoding");	
					try {
						// In order to read files with non-default encoding, specify an encoding in the FileInputStream constructor.
						bufferedReader = new BufferedReader(new InputStreamReader(stream));
						
						char buffer[] = new char[3];
						int length = bufferedReader.read(buffer);
						
						if (length >= 2) {
							if ((buffer[0] == (char) 0xff && buffer[1] == (char) 0xfe) /* UTF-16, little endian */ || 
							    (buffer[0] == (char) 0xfe && buffer[1] == (char) 0xff) /* UTF-16, big endian */) {
								encoding = "UTF16";
							}
						}
						if (length >= 3) {
							if (buffer[0] == (char) 0xef && buffer[1] == (char) 0xbb && buffer[2] == (char) 0xbf) /* UTF-8 */  {
								encoding = "UTF8";
							}
						}
					}
					catch (IOException ex) {
					}
					finally {
						if (bufferedReader != null) {
							try {
								bufferedReader.close();
							}
							catch (IOException ex) {
							}
						}
					}
			 
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "encodingType", encoding );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getServerName (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getServerName)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] field:0:required serverName
		IDataCursor pipelineCursor = pipeline.getCursor();
		IDataUtil.put( pipelineCursor, "serverName", com.wm.app.b2b.server.ServerAPI.getServerName());
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getStackTrace (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getStackTrace)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required exceptionObj
		// [o] field:0:required stackTraceStr
	// pipeline
	IDataCursor pipelineCursor = pipeline.getCursor();
	Object	obj = IDataUtil.get( pipelineCursor, "exceptionObj" );
	pipelineCursor.destroy();

	Exception exceptionObject = (Exception) obj;

	String stackTraceStr = "";

	if(exceptionObject != null) {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		exceptionObject.printStackTrace(pw);
		stackTraceStr = sw.toString();
	}

	// pipeline
	IDataCursor pipelineCursor_1 = pipeline.getCursor();
	IDataUtil.put( pipelineCursor_1, "stackTraceStr", stackTraceStr );
	pipelineCursor_1.destroy();
	
		// --- <<IS-END>> ---

                
	}



	public static final void getSystemInfo (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getSystemInfo)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] field:0:required serverName
		// [o] field:0:required serverPort
		IDataCursor idcPipeline = pipeline.getCursor();
		
			//Output variable
			String strServerName = ServerAPI.getServerName();
			int intCurrentPort = ServerAPI.getCurrentPort();
		
			//insert the serverName into the pipeline	
			idcPipeline.insertAfter("serverName", strServerName);
		
			//insert the currentPort into the pipeline	
			idcPipeline.insertAfter("serverPort", String.valueOf(intCurrentPort));
		
		    // Clean up IData cursors
			idcPipeline.destroy();
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void getTimeMillis (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getTimeMillis)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] field:0:required time
		String time=null;
		
		try{
		time=Long.toString(System.currentTimeMillis());
		
		
		}
		catch(Exception ex){
		
		}
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		IDataUtil.put( pipelineCursor, "time", time );
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getWorkingDirs (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getWorkingDirs)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] field:0:required java_dir
		// [o] field:0:required IS_dir
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		IDataUtil.put( pipelineCursor, "java_dir", System.getProperty("java.home"));
		IDataUtil.put( pipelineCursor, "IS_dir", System.getProperty("user.dir"));
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void lastIndexOf (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(lastIndexOf)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required string1
		// [i] field:0:required stringToBeIndexed
		// [o] field:0:required value
	IDataCursor idcPipeline = pipeline.getCursor();
	String inString = null;
	String stringToBeIndexed = null;
	if (idcPipeline.first("string1"))
	{
		inString = (String)idcPipeline.getValue();
	}
	else
	{
		throw new ServiceException("Input put string is NULL");
	}

	if (idcPipeline.first("stringToBeIndexed"))
	{
		stringToBeIndexed = (String)idcPipeline.getValue();
	}
	else
	{
		throw new ServiceException("String value of which the index should be calculated for, is NULL");
	}

	try
	{
		int lastIndexOfDesiredString = -1;
		lastIndexOfDesiredString = inString.lastIndexOf(stringToBeIndexed);
		String lastIndexInString = "" + lastIndexOfDesiredString;
		// idcProperties.insertAfter(propertyName,propertyValue);

		// Put value back into the output pipeline
		idcPipeline.insertAfter("value", lastIndexInString);
	}
	catch (Exception e)
	{
		throw new ServiceException("Error executing lastIndexOf fucntion :" + e);
	}
	finally
	{	
		idcPipeline.destroy();
	}
		// --- <<IS-END>> ---

                
	}



	public static final void readProperties (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(readProperties)>> ---
		// @sigtype java 3.5
		// [i] field:0:required filename
		// [o] record:0:required JnpProperties
	IDataCursor idcPipeline = pipeline.getCursor();
	String inFile = null;
	if (idcPipeline.first("filename"))
	{
		inFile = (String)idcPipeline.getValue();
	}
	else
	{
		throw new ServiceException("Could not read Juniper properties file. filename is null");
	}

	try
	{
		File file = new File(inFile);
		if (file.canRead())
		{
			Properties property = new Properties();
			InputStream stream  = new java.io.BufferedInputStream(new java.io.FileInputStream(file));
	
			try
			{
				property.load(stream);	
			}
			finally
			{
				stream.close();
			}

			
			IData iProperties = IDataFactory.create();
			IDataCursor idcProperties = iProperties.getCursor();
			Enumeration enum1 = property.propertyNames();
			while  (enum1.hasMoreElements())
			{
				String propertyName = (String)enum1.nextElement();
				String propertyValue = (String)property.getProperty(propertyName);
				idcProperties.insertAfter(propertyName,propertyValue);
			}
		
			// Put entire property object into the output pipeline
			idcPipeline.insertAfter("JnpProperties",iProperties);
		}
		else
		{
			throw new ServiceException("Could not read properties file:" + inFile);
		}
	}
	catch (Exception e)
	{
		throw new ServiceException("Error reading properties file:" + e);
	}
	finally
	{	
		idcPipeline.destroy();
	}
		// --- <<IS-END>> ---

                
	}



	public static final void startsWith (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(startsWith)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required inString
		// [i] field:0:required searchString
		// [i] field:0:required ignoreCase {"true","false"}
		// [o] field:0:required flag
		
		String	inString = null;
		String	searchString = null;
		String ignoreCase=null;
		
		IDataCursor pipelineCursor = pipeline.getCursor();
		if(pipelineCursor.first("inString"))
			inString = IDataUtil.getString( pipelineCursor, "inString" );
		else
			throw new ServiceException("In String is null");
		
		if(pipelineCursor.first("searchString"))
			searchString = IDataUtil.getString( pipelineCursor, "searchString" );
		else
			throw new ServiceException("Search String is null");
		
		if(pipelineCursor.first("searchString"))
			ignoreCase = IDataUtil.getString( pipelineCursor, "ignoreCase" );
		else
			throw new ServiceException("Search String is null");
		
		pipelineCursor.destroy();
		
		boolean bFlag = ignoreCase.equals("true")?(inString.toUpperCase()).startsWith(searchString.toUpperCase()):inString.startsWith(searchString);
		String flag = String.valueOf(bFlag);
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "flag", flag );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void stringArrayToList (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(stringArrayToList)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:required inputArray
		// [o] field:0:required objectList
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String[] inputArray = IDataUtil.getStringArray( pipelineCursor, "inputArray" );
		pipelineCursor.destroy();
		
		Object objectList = new Object();
		if(inputArray !=null)
		objectList=new ArrayList(Arrays.asList(inputArray)); 
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "objectList", objectList.toString() );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void stringToDouble (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(stringToDouble)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required input
		// [o] object:0:required output
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	float_1 = IDataUtil.getString( pipelineCursor, "input" );
		pipelineCursor.destroy();
		try{
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "output", new Double(float_1.trim()));
		pipelineCursor_1.destroy();
		
		}catch(Exception ex){
		
		throw new ServiceException(ex.getMessage());
		}
		// --- <<IS-END>> ---

                
	}



	public static final void stringToTimeStamp (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(stringToTimeStamp)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required date
		// [o] object:0:required date
		try{
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	date = IDataUtil.getString( pipelineCursor, "date" );
		pipelineCursor.destroy();
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		java.util.Date date1 = sdf.parse(date);
		java.sql.Timestamp timestamp = new java.sql.Timestamp(date1.getTime());
		
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "date", timestamp );
		pipelineCursor_1.destroy();
		}
		catch (ParseException e) {
				e.printStackTrace();
			}
		// --- <<IS-END>> ---

                
	}



	public static final void toBigDecimal (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(toBigDecimal)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required input
		// [o] object:0:required output
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	input = IDataUtil.getString( pipelineCursor, "input" );
		pipelineCursor.destroy();
		
		
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "output", new BigDecimal(input.trim()));
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}
}

