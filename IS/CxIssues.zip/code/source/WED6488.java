

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import static java.lang.System.*;
// --- <<IS-END-IMPORTS>> ---

public final class WED6488

{
	// ---( internal utility methods )---

	final static WED6488 _instance = new WED6488();

	static WED6488 _newInstance() { return new WED6488(); }

	static WED6488 _cast(Object o) { return (WED6488)o; }

	// ---( server methods )---




	public static final void new_javaService (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(new_javaService)>> ---
		// @sigtype java 3.5
		out.println();	
			
		// --- <<IS-END>> ---

                
	}
}

