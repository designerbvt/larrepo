package abc;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class xyz

{
	// ---( internal utility methods )---

	final static xyz _instance = new xyz();

	static xyz _newInstance() { return new xyz(); }

	static xyz _cast(Object o) { return (xyz)o; }

	// ---( server methods )---




	public static final void xyz (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(xyz)>> ---
		// @sigtype java 3.5
		// --- <<IS-END>> ---

                
	}
}

