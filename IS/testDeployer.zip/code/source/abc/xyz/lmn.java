package abc.xyz;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class lmn

{
	// ---( internal utility methods )---

	final static lmn _instance = new lmn();

	static lmn _newInstance() { return new lmn(); }

	static lmn _cast(Object o) { return (lmn)o; }

	// ---( server methods )---




	public static final void lmn (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(lmn)>> ---
		// @sigtype java 3.5
		// --- <<IS-END>> ---

                
	}
}

