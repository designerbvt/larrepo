

// -----( IS Java Code Template v1.2
// -----( CREATED: 2016-08-10 14:33:04 IST
// -----( ON-HOST: VMDBVT01.eur.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.app.b2b.server.Session;
import com.wm.util.JournalLogger;
import com.wm.util.DebugMsg;
// --- <<IS-END-IMPORTS>> ---

public final class Resource_2

{
	// ---( internal utility methods )---

	final static Resource_2 _instance = new Resource_2();

	static Resource_2 _newInstance() { return new Resource_2(); }

	static Resource_2 _cast(Object o) { return (Resource_2)o; }

	// ---( server methods )---




	public static final void _put (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(_put)>> ---
		// @sigtype java 3.5
		// [i] field:0:required str
		// [i] field:1:required strl
		// [i] field:2:required strt
		// [i] record:0:required dc
		// [i] record:1:required dcl
		// [i] recref:0:required dcr Resource_2:Doc
		// [i] recref:1:required dcrl Resource_2:Doc
		// [i] object:0:required ob
		// [i] object:1:required obl
		// [o] record:1:required dc
		// [o] - field:0:required str
		// [o] - record:0:required dc_1
		// [o] -- object:0:required ob_1
		// [o] field:1:required strl
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	
	static {
	    try {
	        System.loadLibrary("Resource");
	        JournalLogger.log(DebugMsg.LOG_MSG, JournalLogger.FAC_PACKAGE, JournalLogger.INFO, 
				"Loading native library: Resource");
	    } catch (UnsatisfiedLinkError e) {
	        JournalLogger.logError(DebugMsg.LOG_MSG, JournalLogger.FAC_PACKAGE, 
				e.getMessage());
	    }
	}
	
	native static Values c_delete(Session session, Values in);
		
	// --- <<IS-END-SHARED>> ---
}

