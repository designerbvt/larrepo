package PSUtilities;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2003-01-03 15:54:11 PST
// -----( ON-HOST: eng-114.activesw.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.lang.ns.*;
// --- <<IS-END-IMPORTS>> ---

public final class startup

{
	// ---( internal utility methods )---

	final static startup _instance = new startup();

	static startup _newInstance() { return new startup(); }

	static startup _cast(Object o) { return (startup)o; }

	// ---( server methods )---




	public static final void assignACL (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(assignACL)>> ---
		// @subtype unknown
		// @sigtype java 3.5

	NSName nsPackage = NSName.create("PSUtilities");
	nsPackage.
		// --- <<IS-END>> ---

                
	}
}

