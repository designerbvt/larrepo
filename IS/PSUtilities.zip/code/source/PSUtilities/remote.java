package PSUtilities;

// -----( B2B Java Code Template v1.2
// -----( CREATED: Tue Jul 16 17:07:35 PDT 2002
// -----( ON-HOST: esuc610

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<B2B-START-IMPORTS>> ---
import com.wm.app.b2b.client.TContext;
import java.util.Enumeration;
import com.wm.app.b2b.client.Context;
import com.wm.app.b2b.server.ServerAPI;
// --- <<B2B-END-IMPORTS>> ---

public final class remote
{
	// ---( internal utility methods )---

	final static remote _instance = new remote();

	static remote _newInstance() { return new remote(); }

	static remote _cast(Object o) { return (remote)o; }

	// ---( server methods )---



    public static final Values getRemoteServerInfoHelper (Values in)
    {
        Values out = in;
		// --- <<B2B-START(getRemoteServerInfoHelper)>> ---
		// @sigtype java 3.0
		// [i] field:0:required alias
		// [i] record:0:required servers
		// [o] field:0:required host
		// [o] field:0:required port
		// [o] field:0:required user
		// [o] field:0:required pass
		// [o] field:0:required ssl
		// [o] field:0:required privKeyFile
		// [o] field:0:required certs

	Values servers = in.getValues("servers");
	String alias = in.getString("alias");

	Values serverInfo = servers.getValues(alias);

	if (serverInfo == null)
	{
		out = Service.throwError("Remote server alias \"" + alias + "\" does not exist.");
		return out;
	}

	String host = serverInfo.getString("host");
	String port = serverInfo.getString("port");
	String user = serverInfo.getString("user");
	String pass = serverInfo.getString("pass");
	String ssl = serverInfo.getString("ssl");
	String privKeyFile = serverInfo.getString("privKeyFile");
	String certFiles = serverInfo.getString("certFiles");

	out.put("host", host);
	out.put("port", port);
	out.put("user", user);
	out.put("pass", pass);
	out.put("ssl", ssl);
	out.put("privKeyFile", privKeyFile);
	out.put("certs", certFiles);
		// --- <<B2B-END>> ---
        return out;
                
	}



	public static final void runContextJob (IData pipeline)
        throws ServiceException
	{
		// --- <<B2B-START(runContextJob)>> ---
		// @sigtype java 3.5
		// [i] field:0:required host
		// [i] field:0:required port
		// [i] field:0:required folder
		// [i] field:0:required service
		// [i] field:0:required username
		// [i] field:0:required password
		// [i] field:0:required useSSL {"false","true"}
		// [i] field:0:required privKeyFile
		// [i] field:1:required certFiles
	IDataCursor idcPipeline = pipeline.getCursor();
	idcPipeline.first( "host" );
	String host = (String) idcPipeline.getValue();
	idcPipeline.first( "port" );
	String port = (String) idcPipeline.getValue();
	idcPipeline.first( "folder" );
	String interfaceName = (String) idcPipeline.getValue();
	idcPipeline.first( "service" );
	String serviceName = (String) idcPipeline.getValue();

	idcPipeline.first( "username" );
	String username = (String) idcPipeline.getValue();
	idcPipeline.first( "password" );
	String password = (String) idcPipeline.getValue();

	idcPipeline.first( "useSSL" );
	String useSSL = (String) idcPipeline.getValue();
	idcPipeline.first( "privKeyFile" );
	String privKeyFile = (String) idcPipeline.getValue();
	idcPipeline.first( "certFiles" );
	String certFiles[] = (String []) idcPipeline.getValue();

	try
	{
		String URL = "";
		ServerAPI api = new ServerAPI();
		if (host == null)
			host = api.getServerName();
		if (port == null)
			port = Integer.toString(api.getCurrentPort());

		if (port.equals("-1"))
			URL = host;
		else
			URL = host + ":" + port;
		
		Context context = new Context();
		if (useSSL.equals("true"))
		{
			context.setSecure(true);
		}
		if ((privKeyFile != null) && (certFiles != null))
		{
			context.setSSLCertificates(privKeyFile, certFiles);
		}

		context.connect(URL, username, password);

		IData results = context.invoke(interfaceName, serviceName, pipeline);
		IDataUtil.merge(results, pipeline);

		context.disconnect();

	}
	catch (Exception e)
	{
		throw new ServiceException(e);
	}

	idcPipeline.destroy();
		// --- <<B2B-END>> ---

                
	}



	public static final void runTContextJob (IData pipeline)
        throws ServiceException
	{
		// --- <<B2B-START(runTContextJob)>> ---
		// @sigtype java 3.5
		// [i] field:0:required host
		// [i] field:0:required port
		// [i] field:0:required folder
		// [i] field:0:required service
		// [i] field:0:required username
		// [i] field:0:required password
		// [i] field:0:required ttl
		// [i] field:0:required retries
		// [i] field:0:required useSSL {"false","true"}
		// [i] field:0:required privKeyFile
		// [i] field:1:required certFiles
		// [i] field:0:optional async? {"true","false"}
	int ttl = 0; // if 0 is used, default ttl is used
	int retries = 0;

	IDataCursor pipelineCursor = pipeline.getCursor();
	pipelineCursor.first( "host" );
	String host = (String) pipelineCursor.getValue();
	pipelineCursor.first( "port" );
	String port = (String) pipelineCursor.getValue();
	pipelineCursor.first( "folder" );
	String interfaceName = (String) pipelineCursor.getValue();
	pipelineCursor.first( "service" );
	String serviceName = (String) pipelineCursor.getValue();

	pipelineCursor.first( "username" );
	String username = (String) pipelineCursor.getValue();
	pipelineCursor.first( "password" );
	String password = (String) pipelineCursor.getValue();

	pipelineCursor.first( "useSSL" );
	String useSSL = (String) pipelineCursor.getValue();
	pipelineCursor.first( "privKeyFile" );
	String privKeyFile = (String) pipelineCursor.getValue();
	pipelineCursor.first( "certFiles" );
	String certFiles[] = (String []) pipelineCursor.getValue();
	pipelineCursor.first( "async?" );
	String async = (String) pipelineCursor.getValue();

	if (pipelineCursor.first( "ttl" ))
	{
		String TTL = (String)pipelineCursor.getValue();
		ttl = Integer.parseInt(TTL);
	}
	if (pipelineCursor.first( "retries" ) )
	{
		String Retries = (String) pipelineCursor.getValue();
		retries = Integer.parseInt(Retries);
	}

	//---Initialization----------------------------------------------------
	try
	{
		String URL = "";
		ServerAPI api = new ServerAPI();
		if (host == null)
			host = api.getServerName();
		if (port == null)
			port = Integer.toString(api.getCurrentPort());

		if (port.equals("-1"))
			URL = host;
		else
			URL = host + ":" + port;
	
		//TContext initialization 
		TContext tx = new TContext();
		if (useSSL.equals("true"))
		{
			tx.setSecure(true);
		}

		if ((privKeyFile != null) && (certFiles != null))
		{
			tx.setSSLCertificates(privKeyFile, certFiles);
		}

		tx.connect(URL, username, password);
		
		//start transaction
		String tid = tx.startTx(ttl, retries);
		if (async.equalsIgnoreCase("true"))
		{
	        tx.submitTx(tid, interfaceName, serviceName, pipeline);
		}
		else
		{
	        IData results = tx.invokeTx(tid, interfaceName, serviceName, pipeline);
			IDataUtil.merge(results, pipeline);

		}

        tx.endTx(tid);

		tx.disconnect();
 
	}
	catch (Exception e)
	{
		throw new ServiceException(e);
	}

		// --- <<B2B-END>> ---

                
	}
}

