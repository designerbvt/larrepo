package PSUtilities;

// -----( B2B Java Code Template v1.2
// -----( CREATED: Fri Jun 07 15:14:23 PDT 2002
// -----( ON-HOST: ESU

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<B2B-START-IMPORTS>> ---
import java.net.InetAddress;
import java.net.UnknownHostException;
import com.wm.util.Debug;
import java.io.*;
import java.util.*;
import java.lang.System;
import com.wm.app.b2b.server.*;
import com.wm.util.Table;
import java.text.*;
import com.wm.lang.ns.*;
// --- <<B2B-END-IMPORTS>> ---

public final class wm
{
	// ---( internal utility methods )---

	final static wm _instance = new wm();

	static wm _newInstance() { return new wm(); }

	static wm _cast(Object o) { return (wm)o; }

	// ---( server methods )---




	public static final void appendStringListToStringTable (IData pipeline)
        throws ServiceException
	{
		// --- <<B2B-START(appendStringListToStringTable)>> ---
		// @sigtype java 3.5
		// [i] field:1:required fromStringList
		// [i] field:2:required toStringTable
		// [o] field:2:required toStringTable
		
			IDataCursor idcPipeline = pipeline.getCursor();
		
			idcPipeline.first("fromStringList");
			String fromStringList[] = (String [])idcPipeline.getValue();
			idcPipeline.first("toStringTable");
			String toStringTable[][] = (String[][]) idcPipeline.getValue();
			idcPipeline.delete();
			Values duh = new Values();
			int x = toStringTable.length;
			int y = fromStringList.length;
			if ((x >= 1) && (y != toStringTable[0].length))
			{
				throw new ServiceException("Array sizes are inconsistent");
			}
		System.out.println("x = " + x + ", y = " + y);
			String toStringTableOut[][] = new String[x+1][y];
		
			//Copy toStringTable to output table
			int i, j;
			for (i = 0; i < x; i++)
			{
				for (j = 0; j < y; j++)
				{
					toStringTableOut[i][j] = toStringTable[i][j];
				}
			}
		
			//Append new stringList
			for (j = 0; j < fromStringList.length; j++)
			{
				toStringTableOut[x][j] = fromStringList[j];
			}
		
			idcPipeline.insertAfter("toStringTable", toStringTableOut);
		
			idcPipeline.destroy();
		// --- <<B2B-END>> ---

                
	}


    public static final Values collectGarbage (Values in)
    {
        Values out = in;
		// --- <<B2B-START(collectGarbage)>> ---
		
		System.gc(); 
		// --- <<B2B-END>> ---
        return out;
                
	}


    public static final Values deepConvert (Values in)
    {
        Values out = in;
		// --- <<B2B-START(deepConvert)>> ---
		// @sigtype java 3.0
		// [i] object:0:required hashtable
		// [o] record:0:required convertedValues
		/** This method will deep convert a Hashtable to a Values object.
		  * That is, it will be designed to convert all Hashtable objects within
		  * a hashtable, nested or not, to a values object.
		  *
		  * @author Ryan Johnston, Professional Services, webMethods, Inc.
		  * @version 1.0
		  */
		
		//Get the inbound Hashtable object.
		Hashtable hT = (Hashtable)in.get("hashtable");
		
		boolean nullFlag = false;
		Values outbound = new Values();
		try{
			//Following statement gets all arrays in this object.
			Object[] hTArray = hT.values().toArray();
			Enumeration hTEnumeration = hT.keys();
		
			for(int i=0;i<hTArray.length;i++){
				String key = (String)hTEnumeration.nextElement();
				if(hTArray[i] instanceof java.lang.String){
					outbound.put(key,(String)hTArray[i]);
				}
				else if(hTArray[i] instanceof java.util.Hashtable){
					Values internalObject = convert((Hashtable)hTArray[i]);	
					if(internalObject == null){
						nullFlag = true;
						out.put("convertedValues", null);
						return out;
					}
					outbound.put(key,internalObject);		
				}
				else{
					System.out.println("Conversion Failure:" + "unsupported type within inbound Hashtable.");
					out.put("convertedValues", null);
					return out;
				}
			}
		}
		catch(java.lang.Exception ex){
			System.out.println("Conversion Failure:" + ex.getMessage());
			out.put("convertedValues", null);
			return out;
		}
		out.put("convertedValues",outbound);
		// --- <<B2B-END>> ---
        return out;
                
	}



	public static final void deepCopy (IData pipeline)
        throws ServiceException
	{
		// --- <<B2B-START(deepCopy)>> ---
		// @sigtype java 3.5
		// [i] object:0:required originalObject
		// [o] object:0:required clonedObject
		
			IDataCursor idcPipeline = pipeline.getCursor();
			if (!idcPipeline.first("originalObject"))
			{
				throw new ServiceException("originalObject is null!");
			}
			Object originalObject = (Object)idcPipeline.getValue();
			Object clonedObject = new Object();
		
		//	throw new ServiceException("blah" + (originalObject.getClass()).isArray());
		
			// This code is taken from http://www.javaworld.com/javaworld/javatips/jw-javatip76.html
			ObjectOutputStream oos = null;
			ObjectInputStream ois = null;
		
			try
			{
				ByteArrayOutputStream bos = new ByteArrayOutputStream(); // A
				oos = new ObjectOutputStream(bos); // B
		
				// serialize and pass the object
				oos.writeObject(originalObject); // C
				oos.flush(); // D
		
				ByteArrayInputStream bin = new ByteArrayInputStream(bos.toByteArray()); // E
				ois = new ObjectInputStream(bin); // F
		
				// return the new object
				idcPipeline.insertAfter("clonedObject", ois.readObject()); // G
			}
			catch (Exception e)
			{
				throw new ServiceException("Exception making deep copy of object: " + e);
			}
			finally
			{
				try
				{
					oos.close();
					ois.close();
				}
				catch (Exception e)
				{
					throw new ServiceException("Exception making deep copy of object: " + e);
				}
				idcPipeline.destroy();
			}
		
		// --- <<B2B-END>> ---

                
	}


    public static final Values getHostInformation (Values in)
    {
        Values out = in;
		// --- <<B2B-START(getHostInformation)>> ---
		// @sigtype java 3.0
		// [i] field:0:required host
		// [o] field:0:required IPAddress
		// [o] field:0:required hostName
		
		String strHost = in.getString("host");
		
		try
		{
			InetAddress address = null;
			if (strHost == null)
			{
				// Get local host name
				address = InetAddress.getLocalHost();
			}
			else 
			{
				address = InetAddress.getByName(strHost);
			}
		
			String strHostName = address.getHostName();
			String strIPAddress = address.getHostAddress();
		
			out.put("hostName", strHostName);
			out.put("IPAddress", strIPAddress);
		}
		catch (UnknownHostException e)
		{
			Debug.log (Debug.VERBOSE, "Could not resolve hostname: " + strHost);
		
			out.put("$error", e.getMessage());
			out.put("$errorType", e.toString());
			out.put("$errorMessage", e.getMessage());
		}
		// --- <<B2B-END>> ---
        return out;
                
	}



	public static final void getServerInformation (IData pipeline)
        throws ServiceException
	{
		// --- <<B2B-START(getServerInformation)>> ---
		// @sigtype java 3.5
		// [o] field:0:required serverName
		// [o] field:0:required primaryPort
		// [o] field:0:required currentPort
		
			IDataHashCursor idhcPipeline = pipeline.getHashCursor();
		
			String strServerName = ServerAPI.getServerName();
			int intCurrentPort = ServerAPI.getCurrentPort();
		
			IData listenerInfo = null;
			Integer intPrimaryPort = null;
		
			try
			{
				IData results = Service.doInvoke("wm.server.net.listeners", "getPrimaryListener", pipeline);
				IDataUtil.merge(results, pipeline);
		
			}
			catch(Exception e)
			{
				throw new ServiceException("Could not invoke wm.server.net.listeners:getPrimaryListener: " + e);
			}
		
			if (idhcPipeline.first("primary"))
			{
				listenerInfo = (IData)idhcPipeline.getValue();
				idhcPipeline.delete();
			}
			IDataHashCursor idhcListenerInfo = listenerInfo.getHashCursor();
		
			if (idhcListenerInfo.first("port"))
			{
				intPrimaryPort = (Integer)idhcListenerInfo.getValue();
			}
		
			idhcPipeline.insertAfter("serverName", strServerName);
			idhcPipeline.insertAfter("primaryPort", intPrimaryPort.toString());
			idhcPipeline.insertAfter("currentPort", Integer.toString(intCurrentPort));
		
		// Clean up IData cursors
			idhcListenerInfo.destroy();
			idhcPipeline.destroy();
		// --- <<B2B-END>> ---

                
	}



	public static final void getServiceName (IData pipeline)
        throws ServiceException
	{
		// --- <<B2B-START(getServiceName)>> ---
		// @sigtype java 3.5
		// [o] field:0:required folderName
		// [o] field:0:required serviceName
		// [o] field:0:required fullName
		// [o] field:0:required successFlag
		// [o] field:0:required errorMessage
		/** Service is designed to return the current service name.
		  * Output: folderPath - the folder path to the service
		  *			serviceName - the service name
		  *			fullName - the folder path + ":" + service
		  *			successFlag - true or false
		  *			errorMessage - error detail. This is set to "None" if no error occurs.
		  *
		  * NOTE 1: Because this service relies on a method invocation that retrieves the NSService
		  * 	object relating to the calling service, it will *NOT* work as desired if run independently.
		  * 	Instead, it will return information on the current service (this one) and set the
		  *		"successFlag" and "errorMessage" values to indicate an error.
		  * NOTE 2: This service uses non-public APIs within the webMethods Integration Server. These may 
		  * 	change in future releases of the product *without* notice. These method invocations are
		  *		marked as such.
		  *
		  * @author Ryan Johnston, Professional Services, webMethods, Inc.
		  * @version 1.0
		  */
		
		//Instantiate a cursor for access to the pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		
		//Working & Output Variables - Create all output & working variables
		NSService callingService = null;
		StringTokenizer strTok = null;
		String folderPath = new String();
		String serviceName = new String();
		String fullName = new String();
		String successFlag = "true";
		String errorMessage = "None";
		
		//Input Variables
		//None
		
		//Service Body
		//This publicly documented method gets the NSService object associated with the calling service.
		callingService = Service.getCallingService();
		
		/** If the callingService is not available (meaning that the service was run directly, set the 
		  * "callingService" to hold the values for the current service (this one). Additionally, set the
		  * "successFlag" and "errorMessage" fields to indicate a problem.
		  */
		if(callingService == null){
			callingService = InvokeState.getCurrentService();
			successFlag = "false";
			errorMessage = "No calling service found... Returning information for this service instead.";
		}
		
		/** Non-public API. However, this call is relatively safe, as "toString" is a standard method that
		  * is normally overriden from the root java.lang.Object.
		  */
		fullName = callingService.toString();
		
		/** Use StringTokenizer, from the java.util package, to extract the folderPath and serviceName 
		  * values.
		  */
		try{
			strTok = new StringTokenizer(fullName, ":");
			folderPath = strTok.nextToken();
			serviceName = strTok.nextToken();
		}
		catch(java.lang.Exception ex){
			System.out.println("CRITICAL ERROR: Check the toString() method within NSService to ensure that it is returning Folder:ServiceName as desired.");
			successFlag = "false";
			errorMessage = "CRITICAL ERROR: Check the toString() method within NSService to ensure that it is returning Folder:ServiceName as desired.";
		
		}
		
		//Populate service output
		pipelineCursor.first("folderPath");
		pipelineCursor.delete();
		pipelineCursor.insertAfter("folderPath", folderPath);
		pipelineCursor.first("serviceName");
		pipelineCursor.delete();
		pipelineCursor.insertAfter("serviceName", serviceName);
		pipelineCursor.first("fullName");
		pipelineCursor.delete();
		pipelineCursor.insertAfter("fullName", fullName);
		pipelineCursor.first("successFlag");
		pipelineCursor.delete();
		pipelineCursor.insertAfter("successFlag", successFlag);
		pipelineCursor.first("errorMessage");
		pipelineCursor.delete();
		pipelineCursor.insertAfter("errorMessage", errorMessage);
		// --- <<B2B-END>> ---

                
	}



	public static final void getSpecificSystemProperties (IData pipeline)
        throws ServiceException
	{
		// --- <<B2B-START(getSpecificSystemProperties)>> ---
		// @sigtype java 3.5
		
		IDataCursor idcPipeline = pipeline.getCursor();
		
		IData systemProperties = IDataFactory.create();
		IDataCursor idcSystemProperties = systemProperties.getCursor();
		
		idcSystemProperties.insertAfter("java.version", System.getProperty("java.version"));
		idcSystemProperties.insertAfter("java.vendor", System.getProperty("java.vendor"));
		idcSystemProperties.insertAfter("java.vendor.url", System.getProperty("java.vendor.url"));
		idcSystemProperties.insertAfter("java.home", System.getProperty("java.home"));
		idcSystemProperties.insertAfter("java.class.version", System.getProperty("java.class.version"));
		idcSystemProperties.insertAfter("java.class.path", System.getProperty("java.class.path"));
		idcSystemProperties.insertAfter("os.name", System.getProperty("os.name"));
		idcSystemProperties.insertAfter("os.arch", System.getProperty("os.arch"));
		idcSystemProperties.insertAfter("os.version", System.getProperty("os.version"));
		idcSystemProperties.insertAfter("file.separator", System.getProperty("file.separator"));
		idcSystemProperties.insertAfter("path.separator", System.getProperty("path.separator"));
		idcSystemProperties.insertAfter("line.separator", System.getProperty("line.separator"));
		idcSystemProperties.insertAfter("user.name", System.getProperty("user.name"));
		idcSystemProperties.insertAfter("user.home", System.getProperty("user.home"));
		idcSystemProperties.insertAfter("user.dir", System.getProperty("user.dir"));
		
		idcPipeline.insertAfter("SystemProperties", systemProperties);
		
		idcSystemProperties.destroy();
		idcPipeline.destroy();
		// --- <<B2B-END>> ---

                
	}



	public static final void getSystemProperties (IData pipeline)
        throws ServiceException
	{
		// --- <<B2B-START(getSystemProperties)>> ---
		// @sigtype java 3.5
		// [o] field:2:required propertyList
		/** Service is designed to return a list of all available system properties.
		  *
		  * @author Ryan Johnston, Professional Services, webMethods, Inc.
		  * @version 1.1
		  * Modified slightly to replace IDataHashCursor with IDataCursor (Eric)
		  */
		
		IDataCursor idc = pipeline.getCursor();
		Properties prop = System.getProperties();
		Enumeration propKeyList = prop.propertyNames();
		Vector propVec = new Vector();
		Vector valueVec = new Vector();
		
		outer:while(true){
			if(propKeyList.hasMoreElements() == true){
				String elementName = (String)propKeyList.nextElement();
				String elementValue = System.getProperty(elementName, "No property found");
				propVec.addElement( elementName );
				valueVec.addElement( elementValue );
			}
			else
				break outer;
		}
		
		String[] allPropsColHeaders = {"Key","Value"};
		Table allProps = new Table(allPropsColHeaders);
		for(int i=0;i<propVec.size();i++){
			String[] individualRows = { (String)propVec.elementAt(i),(String)valueVec.elementAt(i) };
			allProps.addRow(individualRows);
		}
		
		idc.first("propertyList");
		idc.delete();
		idc.insertAfter("propertyList", allProps);
		idc.destroy();
		// --- <<B2B-END>> ---

                
	}



	public static final void getSystemProperty (IData pipeline)
        throws ServiceException
	{
		// --- <<B2B-START(getSystemProperty)>> ---
		// @sigtype java 3.5
		// [i] field:0:required propertyName
		// [o] field:0:required property
		/** Service is designed to return the specified system property.
		  *
		  * @author Ryan Johnston, Professional Services, webMethods, Inc.
		  * @version 1.0
		  */
		
		IDataHashCursor hCursor = pipeline.getHashCursor();
		
		hCursor.first("propertyName");
		String propertyName = (String)hCursor.getValue();
		
		String property = new String();
		
		property = System.getProperty(propertyName, "No property found");
		
		hCursor.first("property");
		hCursor.delete();
		hCursor.insertAfter("property", property);
		// --- <<B2B-END>> ---

                
	}



	public static final void getUser (IData pipeline)
        throws ServiceException
	{
		// --- <<B2B-START(getUser)>> ---
		// @sigtype java 3.5
		// [o] field:0:required username

	InvokeState is = InvokeState.getCurrentState();
	User user = is.getCurrentUser();
	String strUsername = user.getName();

	IDataHashCursor idhcPipeline = pipeline.getHashCursor();
	idhcPipeline.insertAfter("username", strUsername);
	idhcPipeline.destroy();
		// --- <<B2B-END>> ---

                
	}


    public static final Values getWebmethodsListenerPorts (Values in)
    {
        Values out = in;
		// --- <<B2B-START(getWebmethodsListenerPorts)>> ---
		// [o] field:0:required httpListenPort
		// [o] field:0:required ftpListenPort
		// [o] field:0:required httpsListenPort

	// Get Ports - returns first active HTTP and FTP active listening ports found

	String httpListenPort = "unknown";
	String ftpListenPort = "unknown";
	String httpsListenPort = "unknown";

	Values portResults = new Values();
 
	try
	{
		portResults = Service.doInvoke("wm.server.net", "listenerList", portResults);
	}
	catch (Exception e)
	{
		Debug.log(Debug.VERBOSE, "Error occurred while getting listening ports:  " + e);
		out.put("httpListenPort", httpListenPort);
		out.put("ftpListenPort", ftpListenPort);
		return out;
	}

	Values [] listeners = (Values []) portResults.get ("listeners");

	if (listeners == null)
	{
		Debug.log (Debug.VERBOSE, "Null listener list returned by server");
	}
	else if (listeners.length == 0)
	{
		Debug.log (Debug.VERBOSE, "Blank listener list returned by server");
	}
	else
	{
		boolean httpListenerFound = false;
		boolean ftpListenerFound = false;
		boolean httpsListenerFound = false;
		String port, protocol, listening;

		int iCounter = 0;

		while ( (!((httpListenerFound) && (ftpListenerFound))) && (iCounter < listeners.length) )
		{
			port = listeners[iCounter].getString ("port");
			protocol = listeners[iCounter].getString ("protocol");
			listening = listeners[iCounter].getString ("listening");

			if ( 	(port != null) &&
					(protocol != null) &&
					(listening!= null) &&
					listening.equals ("true") )
			{
				if (protocol.equals ("HTTP"))
				{
					httpListenPort = port;
					httpListenerFound = true;
				}
				else if (protocol.equals ("FTP"))
				{
					ftpListenPort = port;
					ftpListenerFound = true;
				}
				else if (protocol.equals ("HTTPS"))
				{
					httpsListenPort = port;
					httpsListenerFound = true;
				}
			}
			iCounter++;
		}
	}

	out.put ("httpListenPort", httpListenPort);
	out.put ("ftpListenPort", ftpListenPort);
	out.put ("httpsListenPort", httpsListenPort);
		// --- <<B2B-END>> ---
        return out;
                
	}



	public static final void invoke (IData pipeline)
        throws ServiceException
	{
		// --- <<B2B-START(invoke)>> ---
		// @sigtype java 3.5
		// [i] field:0:required serviceName
		
		IDataHashCursor pipelineCursor = pipeline.getHashCursor();
		String serviceName = null;
		if (pipelineCursor.first("serviceName"))
		{
			serviceName = (String)pipelineCursor.getValue();
		}
		else
		{
			throw new ServiceException("service cannot be null");
		}
		pipelineCursor.destroy();
		
		try
		{
			//Split the interface and service from serviceName
			if (serviceName.indexOf(":") == -1)
			{
				throw new ServiceException("Service name must be in the format <interface>:<service>");
			}
			String ifc = serviceName.substring(0, serviceName.indexOf(":"));
			String service = serviceName.substring(serviceName.indexOf(":") + 1, serviceName.length());
		
			//Invoke service
			Service.doInvoke(ifc,service,pipeline);
		    
		}
		
		catch(Exception e)
		{
			throw new ServiceException(e.getMessage());
		}
		
			
		// --- <<B2B-END>> ---

                
	}



	public static final void invokeAndCatchErrors (IData pipeline)
        throws ServiceException
	{
		// --- <<B2B-START(invokeAndCatchErrors)>> ---
		// @sigtype java 3.5
		// [i] field:0:required interface
		// [i] field:0:required service

	IDataHashCursor idhcPipeline = pipeline.getHashCursor();
	String strServiceName = null;
	String strInterfaceName = null;
	try
	{	
		if (idhcPipeline.first("service"))
		{
			strServiceName = (String)idhcPipeline.getValue();
		}
		else
		{
			throw new ServiceException("Invalid service name");
		}

		if (idhcPipeline.first("interface"))
		{
			strInterfaceName = (String)idhcPipeline.getValue();
		}
		else
		{
			throw new ServiceException("Invalid service name");
		}
	
		if (strServiceName.length() == 0 || strInterfaceName.length() == 0)
			throw new ServiceException("Invalid service name");
		
		NSName nsName = NSName.create(strInterfaceName + ":" + strServiceName);

		IData results = Service.doInvoke(nsName, pipeline);
		IDataUtil.merge(results, pipeline);

	}
	catch(Exception e)
	{
		idhcPipeline.insertAfter("error", e.toString());
		idhcPipeline.insertAfter("errorMessage", e.getMessage());
	}
	finally
	{
		idhcPipeline.destroy();		
	}
		// --- <<B2B-END>> ---

                
	}



	public static final void makeSystemCall (IData pipeline)
        throws ServiceException
	{
		// --- <<B2B-START(makeSystemCall)>> ---
		// @sigtype java 3.5
		// [i] field:0:required command
		// [i] field:0:required synchronous {"true","false"}
		// [o] field:0:required status
		// [o] field:0:required output
		// [o] field:0:required error
		
		// DOS Syntax: cmd.exe /c 'command'
		//             Example: cmd.exe /c copy log.txt log2.txt
		
			IDataCursor idcPipeline = pipeline.getCursor();
			String strOutput = "";
			String strError = "";
			String strCommand = null;
			if (idcPipeline.first("command"))
			{
				strCommand = (String)idcPipeline.getValue();
			}
			else
			{
				return;
			}
			idcPipeline.first("synchronous");
			String strSynchronous = (String)idcPipeline.getValue();
		
			Process process = null;
		
			try
			{
				process = (Runtime.getRuntime()).exec(strCommand);
		
		
				if (strSynchronous.equals("true"))
				{
		
				// Provide an outlet for IO for the process
				String line; 
				BufferedReader ir = new BufferedReader(new InputStreamReader(process.getInputStream())); 
				BufferedReader er = new BufferedReader(new InputStreamReader(process.getErrorStream())); 
				while ((line = ir.readLine()) != null) 
				{
					System.out.println(line);
					strOutput += line + '\n';
				} 
		
				while ((line = er.readLine()) != null) 
				{
					System.out.println(line);
					strError += line + '\n';
				} 
				ir.close(); 
				er.close(); 
		
				process.waitFor();
		
				}
		
			}
			catch (Exception e)
			{
				throw new ServiceException(e.toString());
			}
			finally
			{
				if (strSynchronous.equals("true") && process != null)
				{
					int status = process.exitValue();
					idcPipeline.insertAfter("status", Integer.toString(status));
				}
				idcPipeline.insertAfter("output", strOutput);
				idcPipeline.insertAfter("error", strError);
				process.destroy();
				idcPipeline.destroy();
			}
		// --- <<B2B-END>> ---

                
	}


    public static final Values matchServiceName (Values in)
    {
        Values out = in;
		// --- <<B2B-START(matchServiceName)>> ---
		// @sigtype java 3.0
	Values stats[] = (Values[])in.get("SvcStats");
	String match2 = in.getString("serviceName");

	for (int k = 0; k < stats.length ; k++)
	{
		String match1 = stats[k].getString("name");

		if (match1.equalsIgnoreCase(match2))
		{
    		out.put("firstNumber", stats[k].getString("sRunning"));
			out.put("name", stats[k].getString("name"));
		}

	} 
	out.remove("SvcStats");
		// --- <<B2B-END>> ---
        return out;
                
	}



	public static final void readPropertiesFile (IData pipeline)
        throws ServiceException
	{
		// --- <<B2B-START(readPropertiesFile)>> ---
		// @sigtype java 3.5
		// [i] field:0:required packageName
		// [o] object:0:required property

	IDataHashCursor idhcPipeline = pipeline.getHashCursor();
	String strPackageName = null;
	if (idhcPipeline.first("packageName"))
	{
		strPackageName = (String)idhcPipeline.getValue();
	}
	else
	{
		throw new ServiceException("Could not read Properties file.  packageName is null!");
	}

	File configDir = ServerAPI.getPackageConfigDir(strPackageName);

	String PROP_FILE_NAME = "Params.properties";

	try
	{
		String strFileSeparator = (System.getProperties()).getProperty("file.separator");	

		String strPropertiesFileName = configDir.getPath() + strFileSeparator + PROP_FILE_NAME;
		File file = new File(strPropertiesFileName);
		if (file.canRead())
		{
			Properties property = new Properties();
			InputStream stream = new java.io.BufferedInputStream(new java.io.FileInputStream(file));

			try
			{
				property.load(stream);
			}
			finally
			{
				stream.close();
			}

			Enumeration enum = property.propertyNames();
			while (enum.hasMoreElements())
			{
				String strPropertyName = (String)enum.nextElement();
				String strPropertyValue = (String)property.getProperty(strPropertyName);
				idhcPipeline.insertAfter(strPropertyName, strPropertyValue);				
			}

			// Put entire property object into the output pipeline
			idhcPipeline.insertAfter("property", property);
		}
		else
		{
			throw new ServiceException("Could not read properties file: " + strPropertiesFileName);
		}
	}
	catch( Exception e )
	{
		throw new ServiceException("Error reading properties file: " + e);
	}
		// --- <<B2B-END>> ---

                
	}



	public static final void spawnThread (IData pipeline)
        throws ServiceException
	{
		// --- <<B2B-START(spawnThread)>> ---
		// @sigtype java 3.5
		// [i] field:0:required serviceName
		// [o] object:0:required threadHandle
		
		IDataCursor idcPipeline = pipeline.getCursor();
		String serviceName = null;
		if (idcPipeline.first("serviceName"))
		{
			serviceName = (String)idcPipeline.getValue();
		}
		else
		{
			throw new ServiceException("service cannot be null");
		}
		
		try
		{
			// Split the interface and service from serviceName
			if (serviceName.indexOf(":") == -1)
			{
				throw new ServiceException("Service name must be in the format <interface>:<service>");
			}
			String ifc = serviceName.substring(0, serviceName.indexOf(":"));
			String service = serviceName.substring(serviceName.indexOf(":") + 1, serviceName.length());
		
			// Invoke service
			ServiceThread threadHandle = Service.doThreadInvoke(ifc,service,pipeline);
		    idcPipeline.insertAfter("threadHandle", threadHandle);
		}
		catch(Exception e)
		{
			throw new ServiceException(e.getMessage());
		}
		finally
		{
			idcPipeline.destroy();
		}
		// --- <<B2B-END>> ---

                
	}



	public static final void throwError (IData pipeline)
        throws ServiceException
	{
		// --- <<B2B-START(throwError)>> ---
		// @sigtype java 3.5
		// [i] field:0:required errorMessage
		
		IDataCursor idcPipeline = pipeline.getCursor();
		
		String strErrorMessage = null;
		if (idcPipeline.first("errorMessage"))
		{
			strErrorMessage = (String)idcPipeline.getValue();
		}
		
		
		idcPipeline.destroy();
		
		throw new ServiceException(strErrorMessage);
		// --- <<B2B-END>> ---

                
	}

	// --- <<B2B-START-SHARED>> ---
	/** Used by "deepConvert"
	  * 
	  * @author Ryan Johnston, Professional Services, webMethods, Inc.
	  * @version 1.0
	  */
	private static final Values convert(Hashtable hT){
		//Following statement gets all arrays in this object.
		boolean nullFlag = false;
		Object[] hTArray = hT.values().toArray();
		Enumeration hTEnumeration = hT.keys();
		Values outbound = new Values();
	
		for(int i=0;i<hTArray.length;i++){
			String key = (String)hTEnumeration.nextElement();
			if(hTArray[i] instanceof java.lang.String){
				outbound.put(key,(String)hTArray[i]);
			}
			else if(hTArray[i] instanceof java.util.Hashtable){
				Values internalObject = convert((Hashtable)hTArray[i]);
				if(internalObject == null){
					nullFlag = true;
					return null;
				}
				outbound.put(key,internalObject);						
			}
			else{
				System.out.println("Conversion Failure:" + "unsupported type within inbound Hashtable.");
				return null;
			}
		}
		return outbound; 
	}
	// --- <<B2B-END-SHARED>> ---
}

