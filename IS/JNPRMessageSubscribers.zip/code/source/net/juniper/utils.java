package net.juniper;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.concurrent.ConcurrentHashMap;
// --- <<IS-END-IMPORTS>> ---

public final class utils

{
	// ---( internal utility methods )---

	final static utils _instance = new utils();

	static utils _newInstance() { return new utils(); }

	static utils _cast(Object o) { return (utils)o; }

	// ---( server methods )---




	public static final void incrementDeliveryCount (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(incrementDeliveryCount)>> ---
		// @sigtype java 3.5
		// [i] field:0:required messageId
		// [i] object:0:required deliveryCount
		// [o] field:0:required deliveryCount
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	messageId = IDataUtil.getString( pipelineCursor, "messageId" );
		Object	 deliveryCount = IDataUtil.get( pipelineCursor, "deliveryCount" );
		pipelineCursor.destroy();
		
		if(messageId !=null && deliveryCount !=null){
			try{
				int dc = (Integer) deliveryCount;
				if(localStore.containsKey(messageId)){
					dc = Integer.parseInt(localStore.get(messageId));
					localStore.put(messageId, ++dc+"");
					deliveryCount=Integer.toString(dc);
				}else{
					localStore.put(messageId, deliveryCount+"");
				}
			}catch(Exception ex){
				com.wm.util.JournalLogger.log(3,90,3,"LOG " + "deliveryCount increment error is " +ex.getMessage());
			}
		}
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "deliveryCount", deliveryCount );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void removeMessageIdFromStore (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(removeMessageIdFromStore)>> ---
		// @sigtype java 3.5
		// [i] field:0:required messageId
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	messageId = IDataUtil.getString( pipelineCursor, "messageId" );
		pipelineCursor.destroy();
		
		if(messageId != null && localStore.containsKey(messageId)){
			localStore.remove(messageId);
		}
		
		// pipeline
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	private static ConcurrentHashMap<String, String> localStore = new ConcurrentHashMap();
	// --- <<IS-END-SHARED>> ---
}

